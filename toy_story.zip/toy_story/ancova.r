# ancova
library(tidyverse)
library(ggplot2)
library(afex)

# loading the data
df = read.csv(file.choose(), header = TRUE, sep = ',', stringsAsFactors = FALSE)

attach(df)

# perform ancova using "afex" package

aov.out = aov_ez(id = "id",
                  dv = "du", covariate = c('loc'),
                  between = c("group"), factorize = FALSE, 
                  data = df, anova_table = list(es = "pes", correction = "none"))

aov.out$Anova
summary(aov.out)
knitr::kable(nice(aov.out))

