# check the common prolific id in both groups

# reading survey of control group and experimental group

df_exp = read.csv(file.choose(), header = TRUE, sep = ',', stringsAsFactors = FALSE)

df_ctrl = read.csv(file.choose(), header = TRUE, sep = ',', stringsAsFactors = FALSE)

# finding the common explific id in two groups

common_prolific_id = intersect(df_exp$prolific_id, df_ctrl$prolific_id)

# save it in .csv file

write.table(common_prolific_id, file = paste0('common_prolific_id', '.csv'), sep = ",", col.names = TRUE,
            row.names = FALSE, qmethod = "double")


