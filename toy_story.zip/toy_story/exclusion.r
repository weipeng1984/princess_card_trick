# This is to perform the exclusion
# reading the common prolific id

df_com = read.csv(file.choose(), header = TRUE, sep = ',', stringsAsFactors = FALSE)

# reading the questionnaire

df = read.csv(file.choose(), header = TRUE, sep = ',', stringsAsFactors = FALSE)

df = subset(df, !df$prolific_id %in% df_com$prolific_id)

write.table(df, file = paste0('results-survey142546_exp', '.csv'), sep = ",", col.names = TRUE,
            row.names = FALSE, qmethod = "double")
