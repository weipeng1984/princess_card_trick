
# This is to transfer survey data

library(tidyverse)

# reading survey data

df_survey = read.csv(file.choose(), header = TRUE, sep = ',', stringsAsFactors = FALSE)

names(df_survey)[1] = 'response_id'
names(df_survey)[8] = 'ip'
names(df_survey)[9] = 'prolific_id'
names(df_survey)[10] = 'education'
names(df_survey)[11] = 'gender'
names(df_survey)[12] = 'age'
names(df_survey)[13] = 'country'
names(df_survey)[14] = 'ctrl_q'
names(df_survey)[15] = 'f01'
names(df_survey)[16] = 'f02'
names(df_survey)[17] = 'f03'
names(df_survey)[18] = 'f04'
names(df_survey)[19] = 'f05'
names(df_survey)[20] = 'f06'
names(df_survey)[21] = 'f07'
names(df_survey)[22] = 'f08'
names(df_survey)[23] = 'f09'
names(df_survey)[24] = 'f10'
names(df_survey)[25] = 'f11'
names(df_survey)[26] = 'f12'
names(df_survey)[27] = 'f13'
names(df_survey)[28] = 'f14'
names(df_survey)[29] = 'f15'

df_survey = subset(df_survey, select = c(1, 8:52))

# identify duplicate 

df_survey$ip[duplicated(df_survey$ip)]
df_survey$prolific_id[duplicated(df_survey$prolific_id)]

# now dealing with questions

ctrl_q = as.character(df_survey$ctrl_q)

for (j in 1:length(ctrl_q)) {
  ctrl_q[j] =ifelse(ctrl_q[j] == 'In the video, the magician tricked the men into believing that the men were invisible.', '100%', '0%')
}

df_survey$ctrl_q = ctrl_q

# calculate the free will beliefs (don't reverse the Determinism sub-scale)
# dimension of the data-frame

for (i in 1:dim(df_survey)[1]) {
  for (j in 1:dim(df_survey)[2]) {
    if (df_survey[i, j] == 'Strongly disagree') {
      df_survey[i, j][df_survey[i, j] == 'Strongly disagree'] = 1
    } else if (df_survey[i, j] == 'Disagree') {
      df_survey[i, j][df_survey[i, j] == 'Disagree'] = 2
    } else if (df_survey[i, j] == 'Somewhat disagree') {
      df_survey[i, j][df_survey[i, j] == 'Somewhat disagree'] = 3
    } else if (df_survey[i, j] == 'Neither agree nor disagree') {
      df_survey[i, j][df_survey[i, j] == 'Neither agree nor disagree'] = 4
    } else if (df_survey[i, j] == 'Somewhat agree') {
      df_survey[i, j][df_survey[i, j] == 'Somewhat agree'] = 5
    } else if (df_survey[i, j] == 'Agree') {
      df_survey[i, j][df_survey[i, j] == 'Agree'] = 6
    } else if (df_survey[i, j] == 'Strongly agree') {
      df_survey[i, j][df_survey[i, j] == 'Strongly agree'] = 7
    }
  }
}

freewill = c(9, 12, 15, 18, 21)
determinism = c(10, 13, 16, 19, 22)
dualism = c(11, 14, 17, 20, 23)

# calculating the free will beliefs

df_survey$fw = rowSums(sapply(df_survey[, freewill], as.numeric))

# calculating the Determinism

df_survey$de = rowSums(sapply(df_survey[, determinism], as.numeric))

# calculating the dualism subscale

df_survey$du = rowSums(sapply(df_survey[, dualism], as.numeric))

############################################################################################
# to compute the Locus of Control scale

# item 1

for (i in 1:dim(df_survey)[1]) {
  if (df_survey[i, 24] == "Many of the unhappy things in people’s lives are partly due to bad luck."
      & df_survey[i, 25] == "Slightly well") {
    df_survey[i, 25][df_survey[i, 25] == "Slightly well"] = 3
  } else if (df_survey[i, 24] == "Many of the unhappy things in people’s lives are partly due to bad luck."
      & df_survey[i, 25] == "Very well") {
    df_survey[i, 25][df_survey[i, 25] == "Very well"] = 4
  } else if (df_survey[i, 24] == "People’s misfortunes result from the mistakes they make."
             & df_survey[i, 25] == "Slightly well") {
    df_survey[i, 25][df_survey[i, 25] == "Slightly well"] = 1
  } else if (df_survey[i, 24] == "People’s misfortunes result from the mistakes they make."
             & df_survey[i, 25] == "Very well") {
    df_survey[i, 25][df_survey[i, 25] == "Very well"] = 2
  }
}

# item 2

for (i in 1:dim(df_survey)[1]) {
  if (df_survey[i, 26] == "Unfortunately, an individual’s worth often passes unrecognized no matter how hard he tries."
      & df_survey[i, 27] == 'Slightly well') {
    df_survey[i, 27][df_survey[i, 27] == "Slightly well"] = 3
  } else if (df_survey[i, 26] == "Unfortunately, an individual’s worth often passes unrecognized no matter how hard he tries."
      & df_survey[i, 27] == "Very well") {
    df_survey[i, 27][df_survey[i, 27] == "Very well"] = 4
  } else if (df_survey[i, 26] == "In the long run, people get the respect they deserve in this world."
             & df_survey[i, 27] == "Slightly well") {
    df_survey[i, 27][df_survey[i, 27] == "Slightly well"] = 1
  } else if (df_survey[i, 26] == "In the long run, people get the respect they deserve in this world."
             & df_survey[i, 27] == "Very well") {
    df_survey[i, 27][df_survey[i, 27] == "Very well"] = 2
  }
}

# item 3

for (i in 1:dim(df_survey)[1]) {
  if (df_survey[i, 28] == "Without the right breaks, one cannot be an effective leader."
      & df_survey[i, 29] == "Slightly well") {
    df_survey[i, 29][df_survey[i, 29] == "Slightly well"] = 3
  } else if (df_survey[i, 28] == "Without the right breaks, one cannot be an effective leader."
             & df_survey[i, 29] == "Very well") {
    df_survey[i, 29][df_survey[i, 29] == "Very well"] = 4
  } else if (df_survey[i, 28] == "Capable people who fail to become leaders have not taken advantage of their opportunities."
             & df_survey[i, 29] == "Slightly well") {
    df_survey[i, 29][df_survey[i, 29] == "Slightly well"] = 1
  } else if (df_survey[i, 28] == "Capable people who fail to become leaders have not taken advantage of their opportunities."
             & df_survey[i, 29] == "Very well") {
    df_survey[i, 29][df_survey[i, 29] == "Very well"] = 2
  }
}


# item 4

for (i in 1:dim(df_survey)[1]) {
  if (df_survey[i, 30] == "Getting a good job depends mainly on being in the right place at the right time."
      & df_survey[i, 31] == "Slightly well") {
    df_survey[i, 31][df_survey[i, 31] == "Slightly well"] = 3
  } else if (df_survey[i, 30] == "Getting a good job depends mainly on being in the right place at the right time."
             & df_survey[i, 31] == "Very well") {
    df_survey[i, 31][df_survey[i, 31] == "Very well"] = 4
  } else if (df_survey[i, 30] == "Becoming a success is a matter of hard work; luck has little or nothing to do with it."
             & df_survey[i, 31] == "Slightly well") {
    df_survey[i, 31][df_survey[i, 31] == "Slightly well"] = 1
  } else if (df_survey[i, 30] == "Becoming a success is a matter of hard work; luck has little or nothing to do with it."
             & df_survey[i, 31] == "Very well") {
    df_survey[i, 31][df_survey[i, 31] == "Very well"] = 2
  }
}

# item 5

for (i in 1:dim(df_survey)[1]) {
  if (df_survey[i, 32] == "Sometimes I feel that I don’t have enough control over the direction my life is taking."
      & df_survey[i, 33] == "Slightly well") {
    df_survey[i, 33][df_survey[i, 33] == "Slightly well"] = 3
  } else if (df_survey[i, 32] == "Sometimes I feel that I don’t have enough control over the direction my life is taking."
      & df_survey[i, 33] == "Very well") {
    df_survey[i, 33][df_survey[i, 33] == "Very well"] = 4
  } else if (df_survey[i, 32] == "What happens to me is my own doing."
             & df_survey[i, 33] == "Slightly well") {
    df_survey[i, 33][df_survey[i, 33] == "Slightly well"] = 1
  } else if (df_survey[i, 32] == "What happens to me is my own doing."
             & df_survey[i, 33] == "Very well") {
    df_survey[i, 33][df_survey[i, 33] == "Very well"] = 2
  }
}

# item 6

for (i in 1:dim(df_survey)[1]) {
  if (df_survey[i, 34] == "It is not always wise to plan too far ahead, because many things turn out to be a matter of good or bad fortune anyway."
      & df_survey[i, 35] == "Slightly well") {
    df_survey[i, 35][df_survey[i, 35] == "Slightly well"] = 3
  } else if (df_survey[i, 34] == "It is not always wise to plan too far ahead, because many things turn out to be a matter of good or bad fortune anyway."
             & df_survey[i, 35] == "Very well") {
    df_survey[i, 35][df_survey[i, 35] == "Very well"] = 4
  } else if (df_survey[i, 34] == "When I make plans, I am almost certain that I can make them work."
             & df_survey[i, 35] == "Slightly well") {
    df_survey[i, 35][df_survey[i, 35] == "Slightly well"] = 1
  } else if (df_survey[i, 34] == "When I make plans, I am almost certain that I can make them work."
             & df_survey[i, 35] == "Very well") {
    df_survey[i, 35][df_survey[i, 35] == "Very well"] = 2
  }
}


# item 7

for (i in 1:dim(df_survey)[1]) {
  if (df_survey[i, 36] == "Many times we might just as well decide what to do by flipping a coin."
      & df_survey[i, 37] == "Slightly well") {
    df_survey[i, 37][df_survey[i, 37] == "Slightly well"] = 3
  } else if (df_survey[i, 36] == "Many times we might just as well decide what to do by flipping a coin."
             & df_survey[i, 37] == "Very well") {
    df_survey[i, 37][df_survey[i, 37] == "Very well"] = 4
  } else if (df_survey[i, 36] == "In my case, getting what I want has little or nothing to do with luck."
             & df_survey[i, 37] == "Slightly well") {
    df_survey[i, 37][df_survey[i, 37] == "Slightly well"] = 1
  } else if (df_survey[i, 36] == "In my case, getting what I want has little or nothing to do with luck."
             & df_survey[i, 37] == "Very well") {
    df_survey[i, 37][df_survey[i, 37] == "Very well"] = 2
  }
}

# item 8

for (i in 1:dim(df_survey)[1]) {
  if (df_survey[i, 38] == "Who gets to be boss often depends on who was lucky enough to be in the right place first."
      & df_survey[i, 39] == "Slightly well") {
    df_survey[i, 39][df_survey[i, 39] == "Slightly well"] = 3
  } else if (df_survey[i, 38] == "Who gets to be boss often depends on who was lucky enough to be in the right place first."
             & df_survey[i, 39] == "Very well") {
    df_survey[i, 39][df_survey[i, 39] == "Very well"] = 4
  } else if (df_survey[i, 38] == "Getting people to do the right thing depends upon ability; luck has little or nothing to do with it."
             & df_survey[i, 39] == "Slightly well") {
    df_survey[i, 39][df_survey[i, 39] == "Slightly well"] = 1
  } else if (df_survey[i, 38] == "Getting people to do the right thing depends upon ability; luck has little or nothing to do with it."
             & df_survey[i, 39] == "Very well") {
    df_survey[i, 39][df_survey[i, 39] == "Very well"] = 2
  }
}

# item 9

for (i in 1:dim(df_survey)[1]) {
  if (df_survey[i, 40] == "Most people don’t realize the extent to which their lives are controlled by accidental happenings."
      & df_survey[i, 41] == "Slightly well") {
    df_survey[i, 41][df_survey[i, 41] == "Slightly well"] = 3
  } else if (df_survey[i, 40] == "Most people don’t realize the extent to which their lives are controlled by accidental happenings."
             & df_survey[i, 41] == "Very well") {
    df_survey[i, 41][df_survey[i, 41] == "Very well"] = 4
  } else if (df_survey[i, 40] == 'There is really no such thing as “luck.”'
             & df_survey[i, 41] == "Slightly well") {
    df_survey[i, 41][df_survey[i, 41] == "Slightly well"] = 1
  } else if (df_survey[i, 40] == 'There is really no such thing as “luck.”'
             & df_survey[i, 41] == "Very well") {
    df_survey[i, 41][df_survey[i, 41] == "Very well"] = 2
  }
}


# item 10

for (i in 1:dim(df_survey)[1]) {
  if (df_survey[i, 42] == "In the long run, the bad things that happen to us are balanced by the good ones."
      & df_survey[i, 43] == "Slightly well") {
    df_survey[i, 43][df_survey[i, 43] == "Slightly well"] = 3
  } else if (df_survey[i, 42] == "In the long run, the bad things that happen to us are balanced by the good ones."
             & df_survey[i, 43] == "Very well") {
    df_survey[i, 43][df_survey[i, 43] == "Very well"] = 4
  } else if (df_survey[i, 42] == 'Most misfortunes are the result of lack of ability, ignorance, laziness, or all three.'
             & df_survey[i, 43] == "Slightly well") {
    df_survey[i, 43][df_survey[i, 43] == "Slightly well"] = 1
  } else if (df_survey[i, 42] == 'Most misfortunes are the result of lack of ability, ignorance, laziness, or all three.'
             & df_survey[i, 43] == "Very well") {
    df_survey[i, 43][df_survey[i, 43] == "Very well"] = 2
  }
}

# item 11

for (i in 1:dim(df_survey)[1]) {
  if (df_survey[i, 44] == "Many times I feel that I have little influence over the things that happen to me."
      & df_survey[i, 45] == "Slightly well") {
    df_survey[i, 45][df_survey[i, 45] == "Slightly well"] = 3
  } else if (df_survey[i, 44] == "Many times I feel that I have little influence over the things that happen to me."
             & df_survey[i, 45] == "Very well") {
    df_survey[i, 45][df_survey[i, 45] == "Very well"] = 4
  } else if (df_survey[i, 44] == 'It is impossible for me to believe that chance or luck plays an important role in my life.'
             & df_survey[i, 45] == "Slightly well") {
    df_survey[i, 45][df_survey[i, 45] == "Slightly well"] = 1
  } else if (df_survey[i, 44] == 'It is impossible for me to believe that chance or luck plays an important role in my life.'
             & df_survey[i, 45] == "Very well") {
    df_survey[i, 45][df_survey[i, 45] == "Very well"] = 2
  }
}


df_survey = subset(df_survey, select = c(1:23, 25, 27, 29, 31, 33, 35, 37, 39, 41, 43, 45, 47:49))


write.table(df_survey, file = "survey_ctrl.csv", sep = ",", col.names = TRUE,
            row.names = FALSE, qmethod = "double")


