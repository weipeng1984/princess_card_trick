# Calculating the column sum of locus of control
# v.v Peng Tue Jun 29 18:51:42 2021

library(tidyverse)

# Reading survey data

df = read.csv(file.choose(), header = TRUE, sep = ',', stringsAsFactors = FALSE)

# Summarize the 11 items of locus of control

loc = c(25:35)

# Calculating the free will 

df$loc = rowSums(sapply(df[, loc], as.numeric))

write.table(df, file = "Survey_Pro.csv", sep = ",", col.names = TRUE,
            row.names = FALSE, qmethod = "double")

