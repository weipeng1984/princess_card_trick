# The script here aims at extracting summary of the video content in the file.
# v.v Peng Tue Jun 22 14:01:09 2021

# library packages

library(tidyverse)
library(dplyr)

# Reading the file in batch

filenames = list.files(path = getwd(), pattern = 'Manipulation_AntiGrp_+.*csv')

# Getting the list for prolific id

prolific_id = substr(filenames, 22, 45)

# This function is designed to extract string from the file.
# 17 and 6 are the positions of margin
extract_string = function(s) {
  substr(s, 17, nchar(s) - 6)
  return(substr(s, 17, nchar(s) - 6))
}

# Extracting the summary in each file and then save into .csv file.

summary_text_Anti = data.frame(prolific_id = character(), text_video = character(), stringsAsFactors = FALSE)

for (i in 1:length(prolific_id)) {
  df = read.csv(paste0('Manipulation_AntiGrp_', prolific_id[i], '.csv'), 
                     header = TRUE, sep = ',', stringsAsFactors = FALSE)
  summary_text_Anti[i, 1] = prolific_id[i]
  summary_text_Anti[i, 2] = extract_string(df$responses[5])
}

write.table(summary_text_Anti,
            file = paste0('summary_text_Anti', '.csv'), sep = ",", col.names = TRUE,
            row.names = FALSE, qmethod = "double")

