# Pre-processing the survey data
# v.v Peng Tue Jun 29 16:20:16 2021

library(tidyverse)

# Reading survey data

df = read.csv(file.choose(), header = TRUE, sep = ',', stringsAsFactors = FALSE)

# Choosing the relevant columns and rename the column names (mc: manipulation check)

df = df[, c(1, 6:53)]

names(df)[1] = 'response_id'
names(df)[2] = 'ip'
names(df)[3] = 'prolific_id'
names(df)[4] = 'education'
names(df)[5] = 'gender'
names(df)[6] = 'age'
names(df)[7] = 'country'
names(df)[8] = 'mc_q1'
names(df)[9] = 'mc_q2'
names(df)[10] = 'f01'
names(df)[11] = 'f02'
names(df)[12] = 'f03'
names(df)[13] = 'f04'
names(df)[14] = 'f05'
names(df)[15] = 'f06'
names(df)[16] = 'f07'
names(df)[17] = 'f08'
names(df)[18] = 'f09'
names(df)[19] = 'f10'
names(df)[20] = 'f11'
names(df)[21] = 'f12'
names(df)[22] = 'f13'
names(df)[23] = 'f14'
names(df)[24] = 'f15'

# Identify duplicate 
df$prolific_id[duplicated(df$prolific_id)]

# unify answer option

gender = as.character(df$gender)

for (i in gender) {
  if (i == 'female') {
    gender[gender == 'female'] = 'f'
  } else if (i == 'Female') {
    gender[gender == 'Female'] = 'f'
  } else if (i == 'F') {
    gender[gender == 'F'] = 'f'
  } else if (i == 'FEMALE') {
    gender[gender == 'FEMALE'] = 'f'
  } else if (i == 'Feminino') {
    gender[gender == 'Feminino'] = 'f'
  } else if (i == 'Femmina') {
    gender[gender == 'Femmina'] = 'f'
  } else if (i == 'Famale') {
    gender[gender == 'Famale'] = 'f'
  } else if (i == 'male') {
    gender[gender == 'male'] = 'm'
  } else if (i == 'Male') {
    gender[gender == 'Male'] = 'm'
  } else if (i == 'MALE') {
    gender[gender == 'MALE'] = 'm'
  } else if (i == 'man') {
    gender[gender == 'man'] = 'm'
  } else if (i == 'men') {
    gender[gender == 'men'] = 'm'
  } else if (i == 'women') {
    gender[gender == 'women'] = 'f'
  } else if (i == 'Male ') {
    gender[gender == 'Male '] = 'm'
  } else if (i == 'Female ') {
    gender[gender == 'Female '] = 'f'
  } else if (i == 'Fem') {
    gender[gender == 'Fem'] = 'f'
  } else {
    print('Please check all the levels manually!')
  }
  #return(gender)
}

df$gender = gender

# Performing the manipulation check for the second question

mc_q2 = as.character(df$mc_q2)

for (j in 1:length(mc_q2)) {
  mc_q2[j] =ifelse(mc_q2[j] == 'Whether or not we have free will.', '100%', '0%')
}

df$mc_q2 = mc_q2

# Calculating the free will beliefs (don't reverse the Determinism sub-scale)

for (i in 1:dim(df)[1]) {
  for (j in 1:dim(df)[2]) {
    if (df[i, j] == 'Strongly disagree') {
      df[i, j][df[i, j] == 'Strongly disagree'] = 1
    } else if (df[i, j] == 'Disagree') {
      df[i, j][df[i, j] == 'Disagree'] = 2
    } else if (df[i, j] == 'Somewhat disagree') {
      df[i, j][df[i, j] == 'Somewhat disagree'] = 3
    } else if (df[i, j] == 'Neither agree nor disagree') {
      df[i, j][df[i, j] == 'Neither agree nor disagree'] = 4
    } else if (df[i, j] == 'Somewhat agree') {
      df[i, j][df[i, j] == 'Somewhat agree'] = 5
    } else if (df[i, j] == 'Agree') {
      df[i, j][df[i, j] == 'Agree'] = 6
    } else if (df[i, j] == 'Strongly agree') {
      df[i, j][df[i, j] == 'Strongly agree'] = 7
    }
  }
}

freewill = c(10, 13, 16, 19, 22)
determinism = c(11, 14, 17, 20, 23)
dualism = c(12, 15, 18, 21, 24)


# Calculating the free will 

df$fw = rowSums(sapply(df[, freewill], as.numeric))

# Calculating the determinism

df$de = rowSums(sapply(df[, determinism], as.numeric))

# Calculating the dualism 

df$du = rowSums(sapply(df[, dualism], as.numeric))

############################################################################################
# to compute the Locus of Control scale

# item 1

for (i in 1:dim(df)[1]) {
  if (df[i, 25] == "Many of the unhappy things in people’s lives are partly due to bad luck."
      && df[i, 26] == "Slightly") {
    df[i, 26][df[i, 26] == "Slightly"] = 3
  } else if (df[i, 25] == "Many of the unhappy things in people’s lives are partly due to bad luck."
             && df[i, 26] == "Very") {
    df[i, 26][df[i, 26] == "Very"] = 4
  } else if (df[i, 25] == "People’s misfortunes result from the mistakes they make."
             && df[i, 26] == "Slightly") {
    df[i, 26][df[i, 26] == "Slightly"] = 1
  } else if (df[i, 25] == "People’s misfortunes result from the mistakes they make."
             && df[i, 26] == "Very") {
    df[i, 26][df[i, 26] == "Very"] = 2
  }
}

# item 2

for (i in 1:dim(df)[1]) {
  if (df[i, 27] == "Unfortunately, an individual’s worth often passes unrecognized no matter how hard he tries."
      && df[i, 28] == 'Slightly') {
    df[i, 28][df[i, 28] == "Slightly"] = 3
  } else if (df[i, 27] == "Unfortunately, an individual’s worth often passes unrecognized no matter how hard he tries."
             && df[i, 28] == "Very") {
    df[i, 28][df[i, 28] == "Very"] = 4
  } else if (df[i, 27] == "In the long run, people get the respect they deserve in this world."
             && df[i, 28] == "Slightly") {
    df[i, 28][df[i, 28] == "Slightly"] = 1
  } else if (df[i, 27] == "In the long run, people get the respect they deserve in this world."
             && df[i, 28] == "Very") {
    df[i, 28][df[i, 28] == "Very"] = 2
  }
}

# item 3

for (i in 1:dim(df)[1]) {
  if (df[i, 29] == "Without the right breaks, one cannot be an effective leader."
      && df[i, 30] == "Slightly") {
    df[i, 30][df[i, 30] == "Slightly"] = 3
  } else if (df[i, 29] == "Without the right breaks, one cannot be an effective leader."
             && df[i, 30] == "Very") {
    df[i, 30][df[i, 30] == "Very"] = 4
  } else if (df[i, 29] == "Capable people who fail to become leaders have not taken advantage of their opportunities."
             && df[i, 30] == "Slightly") {
    df[i, 30][df[i, 30] == "Slightly"] = 1
  } else if (df[i, 29] == "Capable people who fail to become leaders have not taken advantage of their opportunities."
             && df[i, 30] == "Very") {
    df[i, 30][df[i, 30] == "Very"] = 2
  }
}


# item 4

for (i in 1:dim(df)[1]) {
  if (df[i, 31] == "Getting a good job depends mainly on being in the right place at the right time."
      && df[i, 32] == "Slightly") {
    df[i, 32][df[i, 32] == "Slightly"] = 3
  } else if (df[i, 31] == "Getting a good job depends mainly on being in the right place at the right time."
             && df[i, 32] == "Very") {
    df[i, 32][df[i, 32] == "Very"] = 4
  } else if (df[i, 31] == "Becoming a success is a matter of hard work; luck has little or nothing to do with it."
             && df[i, 32] == "Slightly") {
    df[i, 32][df[i, 32] == "Slightly"] = 1
  } else if (df[i, 31] == "Becoming a success is a matter of hard work; luck has little or nothing to do with it."
             && df[i, 32] == "Very") {
    df[i, 32][df[i, 32] == "Very"] = 2
  }
}

# item 5

for (i in 1:dim(df)[1]) {
  if (df[i, 33] == "Sometimes I feel that I don’t have enough control over the direction my life is taking."
      && df[i, 34] == "Slightly") {
    df[i, 34][df[i, 34] == "Slightly"] = 3
  } else if (df[i, 33] == "Sometimes I feel that I don’t have enough control over the direction my life is taking."
             && df[i, 34] == "Very") {
    df[i, 34][df[i, 34] == "Very"] = 4
  } else if (df[i, 33] == "What happens to me is my own doing."
             && df[i, 34] == "Slightly") {
    df[i, 34][df[i, 34] == "Slightly"] = 1
  } else if (df[i, 33] == "What happens to me is my own doing."
             && df[i, 34] == "Very") {
    df[i, 34][df[i, 34] == "Very"] = 2
  }
}

# item 6

for (i in 1:dim(df)[1]) {
  if (df[i, 35] == "It is not always wise to plan too far ahead, because many things turn out to be a matter of good or bad fortune anyway."
      && df[i, 36] == "Slightly") {
    df[i, 36][df[i, 36] == "Slightly"] = 3
  } else if (df[i, 35] == "It is not always wise to plan too far ahead, because many things turn out to be a matter of good or bad fortune anyway."
             && df[i, 36] == "Very") {
    df[i, 36][df[i, 36] == "Very"] = 4
  } else if (df[i, 35] == "When I make plans, I am almost certain that I can make them work."
             && df[i, 36] == "Slightly") {
    df[i, 36][df[i, 36] == "Slightly"] = 1
  } else if (df[i, 35] == "When I make plans, I am almost certain that I can make them work."
             && df[i, 36] == "Very") {
    df[i, 36][df[i, 36] == "Very"] = 2
  }
}


# item 7

for (i in 1:dim(df)[1]) {
  if (df[i, 37] == "Many times we might just as well decide what to do by flipping a coin."
      && df[i, 38] == "Slightly") {
    df[i, 38][df[i, 38] == "Slightly"] = 3
  } else if (df[i, 37] == "Many times we might just as well decide what to do by flipping a coin."
             && df[i, 38] == "Very") {
    df[i, 38][df[i, 38] == "Very"] = 4
  } else if (df[i, 37] == "In my case, getting what I want has little or nothing to do with luck."
             && df[i, 38] == "Slightly") {
    df[i, 38][df[i, 38] == "Slightly"] = 1
  } else if (df[i, 37] == "In my case, getting what I want has little or nothing to do with luck."
             && df[i, 38] == "Very") {
    df[i, 38][df[i, 38] == "Very"] = 2
  }
}


# item 8

for (i in 1:dim(df)[1]) {
  if (df[i, 39] == "Who gets to be boss often depends on who was lucky enough to be in the right place first."
      && df[i, 40] == "Slightly") {
    df[i, 40][df[i, 40] == "Slightly"] = 3
  } else if (df[39] == "Who gets to be boss often depends on who was lucky enough to be in the right place first."
             && df[i, 40] == "Very") {
    df[i, 40][df[i, 40] == "Very"] = 4
  } else if (df[i, 39] == "Getting people to do the right thing depends upon ability; luck has little or nothing to do with it."
             && df[i, 40] == "Slightly") {
    df[i, 40][df[i, 40] == "Slightly"] = 1
  } else if (df[i, 39] == "Getting people to do the right thing depends upon ability; luck has little or nothing to do with it."
             && df[i, 40] == "Very") {
    df[i, 40][df[i, 40] == "Very"] = 2
  }
}

# item 9

for (i in 1:dim(df)[1]) {
  if (df[i, 41] == "Most people don’t realize the extent to which their lives are controlled by accidental happenings."
      && df[i, 42] == "Slightly") {
    df[i, 42][df[i, 42] == "Slightly"] = 3
  } else if (df[41] == "Most people don’t realize the extent to which their lives are controlled by accidental happenings."
             && df[i, 42] == "Very") {
    df[i, 42][df[i, 42] == "Very"] = 4
  } else if (df[i, 41] == "There is really no such thing as “luck.”."
             && df[i, 42] == "Slightly") {
    df[i, 42][df[i, 42] == "Slightly"] = 1
  } else if (df[i, 41] == "There is really no such thing as “luck.”"
             && df[i, 42] == "Very") {
    df[i, 42][df[i, 42] == "Very"] = 2
  }
}


# item 10

for (i in 1:dim(df)[1]) {
  if (df[i, 44] == "In the long run, the bad things that happen to us are balanced by the good ones."
      && df[i, 44] == "Slightly") {
    df[i, 44][df[i, 44] == "Slightly"] = 3
  } else if (df[43] == "In the long run, the bad things that happen to us are balanced by the good ones."
             && df[i, 44] == "Very") {
    df[i, 44][df[i, 44] == "Very"] = 4
  } else if (df[i, 43] == "Most misfortunes are the result of lack of ability, ignorance, laziness, or all three."
             && df[i, 44] == "Slightly") {
    df[i, 44][df[i, 44] == "Slightly"] = 1
  } else if (df[i, 43] == "Most misfortunes are the result of lack of ability, ignorance, laziness, or all three."
             && df[i, 44] == "Very") {
    df[i, 44][df[i, 44] == "Very"] = 2
  }
}


# item 11

for (i in 1:dim(df)[1]) {
  if (df[i, 45] == "Many times I feel that I have little influence over the things that happen to me."
      && df[i, 46] == "Slightly") {
    df[i, 46][df[i, 46] == "Slightly"] = 3
  } else if (df[45] == "Many times I feel that I have little influence over the things that happen to me."
             && df[i, 46] == "Very") {
    df[i, 46][df[i, 46] == "Very"] = 4
  } else if (df[i, 45] == "It is impossible for me to believe that chance or luck plays an important role in my life."
             && df[i, 46] == "Slightly") {
    df[i, 46][df[i, 46] == "Slightly"] = 1
  } else if (df[i, 45] == "It is impossible for me to believe that chance or luck plays an important role in my life."
             && df[i, 46] == "Very") {
    df[i, 46][df[i, 46] == "Very"] = 2
  }
}

df = subset(df, select = c(1:24, 26, 28, 30, 32, 34, 36, 38, 40, 42, 44, 46, 47:52))


write.table(df, file = "Survey_Pro.csv", sep = ",", col.names = TRUE,
            row.names = FALSE, qmethod = "double")


