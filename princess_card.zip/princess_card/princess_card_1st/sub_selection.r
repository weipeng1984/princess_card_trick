# Read the ID file

df_ID = read.csv(file.choose(), header = TRUE, sep = ',', stringsAsFactors = FALSE)

# Read the target file

df = read.csv(file.choose(), header = TRUE, sep = ',', stringsAsFactors = FALSE)

attach(df)

df = subset(df, df$Response.ID %in% df_ID$response_id)

write.table(df, file = "results-survey593373_Pro.csv", sep = ",", col.names = TRUE,
            row.names = FALSE, qmethod = "double")
