# Exclude some participants based on the duplicated prolific id

library(dplyr)

# reading the data

df_anti = read.csv(file.choose(), header = TRUE, sep = ',', stringsAsFactors = FALSE)

# reading the duplicated id

df_dupli = read.csv(file.choose(), header = TRUE, sep = ',', stringsAsFactors = FALSE)

# to remove the duplicate prolific id

df_anti = df_anti[!df_anti$prolific_id %in% df_dupli$prolific_id, ]

write.table(df_anti, file = "Survey_Anti.csv", sep = ",", col.names = TRUE,
            row.names = FALSE, qmethod = "double")
