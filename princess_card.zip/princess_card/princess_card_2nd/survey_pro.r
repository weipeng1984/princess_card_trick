# Pre-processing the survey data
# v.v Peng Tue Jun 22 16:20:16 2021

library(tidyverse)

# Reading survey data

df = read.csv(file.choose(), header = TRUE, sep = ',', stringsAsFactors = FALSE)

# Choosing the relevant columns and rename the column names (mc: manipulation check)

df = df[, c(1, 6:51)]

names(df)[1] = 'response_id'
names(df)[2] = 'ip'
names(df)[3] = 'prolific_id'
names(df)[4] = 'education'
names(df)[5] = 'gender'
names(df)[6] = 'age'
names(df)[7] = 'country'
names(df)[8] = 'mc_q1'
names(df)[9] = 'f01'
names(df)[10] = 'f02'
names(df)[11] = 'f03'
names(df)[12] = 'f04'
names(df)[13] = 'f05'
names(df)[14] = 'f06'
names(df)[15] = 'f07'
names(df)[16] = 'f08'
names(df)[17] = 'f09'
names(df)[18] = 'f10'
names(df)[19] = 'f11'
names(df)[20] = 'f12'
names(df)[21] = 'f13'
names(df)[22] = 'f14'
names(df)[23] = 'f15'

# Identify duplicate 
df$prolific_id[duplicated(df$prolific_id)]

# unify answer option

gender = as.character(df$gender)

for (i in gender) {
  if (i == 'female') {
    gender[gender == 'female'] = 'f'
  } else if (i == 'Female') {
    gender[gender == 'Female'] = 'f'
  } else if (i == 'F') {
    gender[gender == 'F'] = 'f'
  } else if (i == 'FEMALE') {
    gender[gender == 'FEMALE'] = 'f'
  } else if (i == 'Feminino') {
    gender[gender == 'Feminino'] = 'f'
  } else if (i == 'Femmina') {
    gender[gender == 'Femmina'] = 'f'
  } else if (i == 'Famale') {
    gender[gender == 'Famale'] = 'f'
  } else if (i == 'male') {
    gender[gender == 'male'] = 'm'
  } else if (i == 'Male') {
    gender[gender == 'Male'] = 'm'
  } else if (i == 'MALE') {
    gender[gender == 'MALE'] = 'm'
  } else if (i == 'man') {
    gender[gender == 'man'] = 'm'
  } else if (i == 'men') {
    gender[gender == 'men'] = 'm'
  } else if (i == 'women') {
    gender[gender == 'women'] = 'f'
  } else if (i == 'Male ') {
    gender[gender == 'Male '] = 'm'
  } else if (i == 'Female ') {
    gender[gender == 'Female '] = 'f'
  } else if (i == 'Fem') {
    gender[gender == 'Fem'] = 'f'
  } else {
    print('Please check all the levels manually!')
  }
  #return(gender)
}

df$gender = gender

# Performing the manipulation check for the second question

mc_q1 = as.character(df$mc_q1)

for (j in 1:length(mc_q1)) {
  mc_q1[j] =ifelse(mc_q1[j] == 'Whether or not we have free will.', '100%', '0%')
}

df$mc_q1 = mc_q1

# Calculating the free will beliefs (don't reverse the Determinism sub-scale)

for (i in 1:dim(df)[1]) {
  for (j in 1:dim(df)[2]) {
    if (df[i, j] == 'Strongly disagree') {
      df[i, j][df[i, j] == 'Strongly disagree'] = 1
    } else if (df[i, j] == 'Disagree') {
      df[i, j][df[i, j] == 'Disagree'] = 2
    } else if (df[i, j] == 'Somewhat disagree') {
      df[i, j][df[i, j] == 'Somewhat disagree'] = 3
    } else if (df[i, j] == 'Neither agree nor disagree') {
      df[i, j][df[i, j] == 'Neither agree nor disagree'] = 4
    } else if (df[i, j] == 'Somewhat agree') {
      df[i, j][df[i, j] == 'Somewhat agree'] = 5
    } else if (df[i, j] == 'Agree') {
      df[i, j][df[i, j] == 'Agree'] = 6
    } else if (df[i, j] == 'Strongly agree') {
      df[i, j][df[i, j] == 'Strongly agree'] = 7
    }
  }
}

freewill = c(9, 12, 15, 18, 21)
determinism = c(10, 13, 16, 19, 22)
dualism = c(11, 14, 17, 20, 23)

# Calculating the free will 

df$fw = rowSums(sapply(df[, freewill], as.numeric))

# Calculating the determinism

df$de = rowSums(sapply(df[, determinism], as.numeric))

# Calculating the dualism 

df$du = rowSums(sapply(df[, dualism], as.numeric))

############################################################################################
# to compute the Locus of Control scale

# item 1

for (i in 1:dim(df)[1]) {
  if (df[i, 24] == "Many of the unhappy things in people’s lives are partly due to bad luck."
      && df[i, 25] == "Slightly") {
    df[i, 25][df[i, 25] == "Slightly"] = 3
  } else if (df[i, 24] == "Many of the unhappy things in people’s lives are partly due to bad luck."
             && df[i, 25] == "Very") {
    df[i, 25][df[i, 25] == "Very"] = 4
  } else if (df[i, 24] == "People’s misfortunes result from the mistakes they make."
             && df[i, 25] == "Slightly") {
    df[i, 25][df[i, 25] == "Slightly"] = 1
  } else if (df[i, 24] == "People’s misfortunes result from the mistakes they make."
             && df[i, 25] == "Very") {
    df[i, 25][df[i, 25] == "Very"] = 2
  }
}

# item 2

for (i in 1:dim(df)[1]) {
  if (df[i, 26] == "Unfortunately, an individual’s worth often passes unrecognized no matter how hard he tries."
      && df[i, 27] == 'Slightly') {
    df[i, 27][df[i, 27] == "Slightly"] = 3
  } else if (df[i, 26] == "Unfortunately, an individual’s worth often passes unrecognized no matter how hard he tries."
             && df[i, 27] == "Very") {
    df[i, 27][df[i, 27] == "Very"] = 4
  } else if (df[i, 26] == "In the long run, people get the respect they deserve in this world."
             && df[i, 27] == "Slightly") {
    df[i, 27][df[i, 27] == "Slightly"] = 1
  } else if (df[i, 26] == "In the long run, people get the respect they deserve in this world."
             && df[i, 27] == "Very") {
    df[i, 27][df[i, 27] == "Very"] = 2
  }
}

# item 3

for (i in 1:dim(df)[1]) {
  if (df[i, 28] == "Without the right breaks, one cannot be an effective leader."
      && df[i, 29] == "Slightly") {
    df[i, 29][df[i, 29] == "Slightly"] = 3
  } else if (df[i, 28] == "Without the right breaks, one cannot be an effective leader."
             && df[i, 29] == "Very") {
    df[i, 29][df[i, 29] == "Very"] = 4
  } else if (df[i, 28] == "Capable people who fail to become leaders have not taken advantage of their opportunities."
             && df[i, 29] == "Slightly") {
    df[i, 29][df[i, 29] == "Slightly"] = 1
  } else if (df[i, 28] == "Capable people who fail to become leaders have not taken advantage of their opportunities."
             && df[i, 29] == "Very") {
    df[i, 29][df[i, 29] == "Very"] = 2
  }
}


# item 4

for (i in 1:dim(df)[1]) {
  if (df[i, 30] == "Getting a good job depends mainly on being in the right place at the right time."
      && df[i, 31] == "Slightly") {
    df[i, 31][df[i, 31] == "Slightly"] = 3
  } else if (df[i, 30] == "Getting a good job depends mainly on being in the right place at the right time."
             && df[i, 31] == "Very") {
    df[i, 31][df[i, 31] == "Very"] = 4
  } else if (df[i, 30] == "Becoming a success is a matter of hard work; luck has little or nothing to do with it."
             && df[i, 31] == "Slightly") {
    df[i, 31][df[i, 31] == "Slightly"] = 1
  } else if (df[i, 30] == "Becoming a success is a matter of hard work; luck has little or nothing to do with it."
             && df[i, 31] == "Very") {
    df[i, 31][df[i, 31] == "Very"] = 2
  }
}

# item 5

for (i in 1:dim(df)[1]) {
  if (df[i, 32] == "Sometimes I feel that I don’t have enough control over the direction my life is taking."
      && df[i, 33] == "Slightly") {
    df[i, 33][df[i, 33] == "Slightly"] = 3
  } else if (df[i, 32] == "Sometimes I feel that I don’t have enough control over the direction my life is taking."
             && df[i, 33] == "Very") {
    df[i, 33][df[i, 33] == "Very"] = 4
  } else if (df[i, 32] == "What happens to me is my own doing."
             && df[i, 33] == "Slightly") {
    df[i, 33][df[i, 33] == "Slightly"] = 1
  } else if (df[i, 32] == "What happens to me is my own doing."
             && df[i, 33] == "Very") {
    df[i, 33][df[i, 33] == "Very"] = 2
  }
}

# item 6

for (i in 1:dim(df)[1]) {
  if (df[i, 34] == "It is not always wise to plan too far ahead, because many things turn out to be a matter of good or bad fortune anyway."
      && df[i, 35] == "Slightly") {
    df[i, 35][df[i, 35] == "Slightly"] = 3
  } else if (df[i, 34] == "It is not always wise to plan too far ahead, because many things turn out to be a matter of good or bad fortune anyway."
             && df[i, 35] == "Very") {
    df[i, 35][df[i, 35] == "Very"] = 4
  } else if (df[i, 34] == "When I make plans, I am almost certain that I can make them work."
             && df[i, 35] == "Slightly") {
    df[i, 35][df[i, 35] == "Slightly"] = 1
  } else if (df[i, 34] == "When I make plans, I am almost certain that I can make them work."
             && df[i, 35] == "Very") {
    df[i, 35][df[i, 35] == "Very"] = 2
  }
}


# item 7

for (i in 1:dim(df)[1]) {
  if (df[i, 36] == "Many times we might just as well decide what to do by flipping a coin."
      && df[i, 37] == "Slightly") {
    df[i, 37][df[i, 37] == "Slightly"] = 3
  } else if (df[i, 36] == "Many times we might just as well decide what to do by flipping a coin."
             && df[i, 37] == "Very") {
    df[i, 37][df[i, 37] == "Very"] = 4
  } else if (df[i, 36] == "In my case, getting what I want has little or nothing to do with luck."
             && df[i, 37] == "Slightly") {
    df[i, 37][df[i, 37] == "Slightly"] = 1
  } else if (df[i, 36] == "In my case, getting what I want has little or nothing to do with luck."
             && df[i, 37] == "Very") {
    df[i, 37][df[i, 37] == "Very"] = 2
  }
}


# item 8

for (i in 1:dim(df)[1]) {
  if (df[i, 38] == "Who gets to be boss often depends on who was lucky enough to be in the right place first."
      && df[i, 39] == "Slightly") {
    df[i, 39][df[i, 39] == "Slightly"] = 3
  } else if (df[38] == "Who gets to be boss often depends on who was lucky enough to be in the right place first."
             && df[i, 39] == "Very") {
    df[i, 39][df[i, 39] == "Very"] = 4
  } else if (df[i, 38] == "Getting people to do the right thing depends upon ability; luck has little or nothing to do with it."
             && df[i, 39] == "Slightly") {
    df[i, 39][df[i, 39] == "Slightly"] = 1
  } else if (df[i, 38] == "Getting people to do the right thing depends upon ability; luck has little or nothing to do with it."
             && df[i, 39] == "Very") {
    df[i, 39][df[i, 39] == "Very"] = 2
  }
}

# item 9

for (i in 1:dim(df)[1]) {
  if (df[i, 40] == "Most people don’t realize the extent to which their lives are controlled by accidental happenings."
      && df[i, 41] == "Slightly") {
    df[i, 41][df[i, 41] == "Slightly"] = 3
  } else if (df[40] == "Most people don’t realize the extent to which their lives are controlled by accidental happenings."
             && df[i, 41] == "Very") {
    df[i, 41][df[i, 41] == "Very"] = 4
  } else if (df[i, 40] == 'There is really no such thing as “luck.”'
             && df[i, 41] == "Slightly") {
    df[i, 41][df[i, 41] == "Slightly"] = 1
  } else if (df[i, 40] == 'There is really no such thing as “luck.”'
             && df[i, 41] == "Very") {
    df[i, 41][df[i, 41] == "Very"] = 2
  }
}


# item 10

for (i in 1:dim(df)[1]) {
  if (df[i, 42] == "In the long run, the bad things that happen to us are balanced by the good ones."
      && df[i, 43] == "Slightly") {
    df[i, 43][df[i, 43] == "Slightly"] = 3
  } else if (df[42] == "In the long run, the bad things that happen to us are balanced by the good ones."
             && df[i, 43] == "Very") {
    df[i, 43][df[i, 43] == "Very"] = 4
  } else if (df[i, 42] == "Most misfortunes are the result of lack of ability, ignorance, laziness, or all three."
             && df[i, 43] == "Slightly") {
    df[i, 43][df[i, 43] == "Slightly"] = 1
  } else if (df[i, 42] == "Most misfortunes are the result of lack of ability, ignorance, laziness, or all three."
             && df[i, 43] == "Very") {
    df[i, 43][df[i, 43] == "Very"] = 2
  }
}


# item 11

for (i in 1:dim(df)[1]) {
  if (df[i, 44] == "Many times I feel that I have little influence over the things that happen to me."
      && df[i, 45] == "Slightly") {
    df[i, 45][df[i, 45] == "Slightly"] = 3
  } else if (df[44] == "Many times I feel that I have little influence over the things that happen to me."
             && df[i, 45] == "Very") {
    df[i, 45][df[i, 45] == "Very"] = 4
  } else if (df[i, 44] == "It is impossible for me to believe that chance or luck plays an important role in my life."
             && df[i, 45] == "Slightly") {
    df[i, 45][df[i, 45] == "Slightly"] = 1
  } else if (df[i, 44] == "It is impossible for me to believe that chance or luck plays an important role in my life."
             && df[i, 45] == "Very") {
    df[i, 45][df[i, 45] == "Very"] = 2
  }
}

df = subset(df, select = c(1:23, 25, 27, 29, 31, 33, 35, 37, 39, 41, 43, 45, 47:50))


write.table(df, file = "Survey_Pro.csv", sep = ",", col.names = TRUE,
            row.names = FALSE, qmethod = "double")


