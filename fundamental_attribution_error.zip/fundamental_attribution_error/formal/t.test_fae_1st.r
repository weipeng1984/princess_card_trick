
# manipulation check
library(car)
library(knitr)
library(apa)
library(ggplot2)

# perform t test in this study

df_ext = read.csv(file.choose(), header = TRUE, sep = ',', stringsAsFactors = FALSE)

df_int = read.csv(file.choose(), header = TRUE, sep = ',', stringsAsFactors = FALSE)

fae = stack(list(int = df_int$int, ext = df_ext$ext))

# for first analysis - comparing internal to external attributions across the two groups (internal > external)

t_apa(t_test(df_int$int, df_ext$ext, var.equal = FALSE))

# descriptive data - free will

library(dplyr)
# Summarize data by groups
fae_new = fae %>% # "Start with the data set we imported, d 
  group_by(ind) %>% # Then group d by IV
  summarize(N = length(values), # Then summarize each group
            Mean = mean(values),
            SD = sd(values),
            SE = SD/sqrt(N)) 
kable(fae_new, digits = 2)

#################################################################
# now we plotting
# fae

fae_plot = ggplot(fae, aes(x = ind, y = values, fill = ind)) + 
  geom_violin(trim = FALSE) + 
  geom_boxplot(width = 0.1, fill = "white")+
  labs(title="Plot of attribution by group", x = "Group", y = "Score of the Fundamental Attribution Error")
fae_plot + scale_fill_brewer(palette = "Dark2") + theme_minimal()


