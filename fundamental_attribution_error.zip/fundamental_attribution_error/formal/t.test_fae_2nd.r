
# manipulation check
library(car)
library(knitr)
library(apa)
library(ggplot2)

# perform t test in this study

df_pro = read.csv(file.choose(), header = TRUE, sep = ',', stringsAsFactors = FALSE)

df_anti = read.csv(file.choose(), header = TRUE, sep = ',', stringsAsFactors = FALSE)

corre_bias = stack(list(pro = df_pro$corre_bias, anti = df_anti$corre_bias))

# Comparing the correspondence bias between two groups

t_apa(t_test(df_pro$corre_bias, df_anti$corre_bias, var.equal = FALSE))

# descriptive data - free will

library(dplyr)
# Summarize data by groups
corre_bias_new = corre_bias %>% # "Start with the data set we imported, d 
  group_by(ind) %>% # Then group d by IV
  summarize(N = length(values), # Then summarize each group
            Mean = mean(values),
            SD = sd(values),
            SE = SD/sqrt(N)) 
kable(corre_bias_new, digits = 2)

#################################################################
# now we plotting
# fae

corre_bias_plot = ggplot(corre_bias, aes(x = ind, y = values, fill = ind)) + 
  geom_violin(trim = FALSE) + 
  geom_boxplot(width = 0.1, fill = "white")+
  labs(title="Plot of Bias by group", x = "Group", y = "Score of the Correspondence Bias")
corre_bias_plot + scale_fill_brewer(palette = "Dark2") + theme_minimal()


