# check the common prolific id in both groups

# reading survey of control group and antierimental group

df_anti = read.csv(file.choose(), header = TRUE, sep = ',', stringsAsFactors = FALSE)

df_pro = read.csv(file.choose(), header = TRUE, sep = ',', stringsAsFactors = FALSE)

# finding the common prolific id in two groups

common_prolific_id = intersect(df_anti$prolific_id, df_pro$prolific_id)

# save it in .csv file

write.table(common_prolific_id, file = paste0('common_prolific_id', '.csv'), sep = ",", col.names = TRUE,
            row.names = FALSE, qmethod = "double")


