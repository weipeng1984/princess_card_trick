# for calculating Cronbach's alpha value

library(psych)

df = read.csv(file.choose() ,header = T, sep = ",", stringsAsFactors = FALSE)

alpha(fw)

fw = df[, c(25, 28, 31, 34, 37)]
de = df[, c(26, 29, 32, 35, 38)]
du = df[, c(27, 30, 33, 36, 39)]


