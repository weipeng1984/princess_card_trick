# Pre_processing the survey data
# v.v Peng Mon Nov 15 13:07:26 2021

library(tidyverse)

# Reading survey data

df = read.csv(file.choose(), header = TRUE, sep = ',', stringsAsFactors = FALSE)

# Choosing the relevant columns and rename the column names (mc: manipulation check)

df = df[, c(1, 6:44, 46)]

names(df)[1] = 'response_id'
names(df)[2] = 'ip'
names(df)[3] = 'prolific_id'
names(df)[4] = 'education'
names(df)[5] = 'gender'
names(df)[6] = 'age'
names(df)[7] = 'country'
names(df)[8] = 'mc_q1'
names(df)[9] = 's1_01'
names(df)[10] = 's1_02'
names(df)[11] = 's1_03' 
names(df)[12] = 's1_04'
names(df)[13] = 's2_01'
names(df)[14] = 's2_02'
names(df)[15] = 's2_03'
names(df)[16] = 's2_04'
names(df)[17] = 's3_01'
names(df)[18] = 's3_02'
names(df)[19] = 's3_03'
names(df)[20] = 's3_04'
names(df)[21] = 's4_01'
names(df)[22] = 's4_02'
names(df)[23] = 's4_03'
names(df)[24] = 's4_04'
names(df)[25] = 'f01'
names(df)[26] = 'f02'
names(df)[27] = 'f03'
names(df)[28] = 'f04'
names(df)[29] = 'f05'
names(df)[30] = 'f06'
names(df)[31] = 'f07'
names(df)[32] = 'f08'
names(df)[33] = 'f09'
names(df)[34] = 'f10'
names(df)[35] = 'f11'
names(df)[36] = 'f12'
names(df)[37] = 'f13'
names(df)[38] = 'f14'
names(df)[39] = 'f15'
names(df)[40] = 'mc_q2'
names(df)[41] = 'mc_q3'

# Identify duplicate 

df$prolific_id[duplicated(df$prolific_id)]

# Performing the manipulation check for the first question

mc_q1 = as.character(df$mc_q1)

for (j in 1:length(mc_q1)) {
  mc_q1[j] =ifelse(mc_q1[j] == 'Whether or not we have free will.', '100%', '0%')
}

df$mc_q1 = mc_q1

# Performing the manipulation check for the third question

mc_q3 = as.character(df$mc_q3)

for (j in 1:length(mc_q3)) {
  mc_q3[j] =ifelse(mc_q3[j] == 'Yes', '100%', '0%')
}

df$mc_q3 = mc_q3

# Performing the manipulation check for the second question

for (i in 1:dim(df)[1]) {
  for (j in 1:dim(df)[2]) {
    if (df[i, j] == 'Strongly unconvincing') {
      df[i, j][df[i, j] == 'Strongly unconvincing'] = 1
    } else if (df[i, j] == 'unconvincing') {
      df[i, j][df[i, j] == 'unconvincing'] = 2
    } else if (df[i, j] == 'Somewhat unconvincing') {
      df[i, j][df[i, j] == 'Somewhat unconvincing'] = 3
    } else if (df[i, j] == 'Neither convincing nor unconvincing') {
      df[i, j][df[i, j] == 'Neither convincing nor unconvincing'] = 4
    } else if (df[i, j] == 'Somewhat convincing') {
      df[i, j][df[i, j] == 'Somewhat convincing'] = 5
    } else if (df[i, j] == 'convincing') {
      df[i, j][df[i, j] == 'convincing'] = 6
    } else if (df[i, j] == 'Strongly convincing') {
      df[i, j][df[i, j] == 'Strongly convincing'] = 7
    }
  }
}

# Calculating the Free Will Inventory and Fundamental Attribution Error

for (i in 1:dim(df)[1]) {
  for (j in 1:dim(df)[2]) {
    if (df[i, j] == 'Strongly disagree') {
      df[i, j][df[i, j] == 'Strongly disagree'] = 1
    } else if (df[i, j] == 'Disagree') {
      df[i, j][df[i, j] == 'Disagree'] = 2
    } else if (df[i, j] == 'Somewhat disagree') {
      df[i, j][df[i, j] == 'Somewhat disagree'] = 3
    } else if (df[i, j] == 'Neither agree nor disagree') {
      df[i, j][df[i, j] == 'Neither agree nor disagree'] = 4
    } else if (df[i, j] == 'Somewhat agree') {
      df[i, j][df[i, j] == 'Somewhat agree'] = 5
    } else if (df[i, j] == 'Agree') {
      df[i, j][df[i, j] == 'Agree'] = 6
    } else if (df[i, j] == 'Strongly agree') {
      df[i, j][df[i, j] == 'Strongly agree'] = 7
    }
  }
}

freewill = c(25, 28, 31, 34, 37)
determinism = c(26, 29, 32, 35, 38)
dualism = c(27, 30, 33, 36, 39)

# Calculating the free will 

df$fw = rowSums(sapply(df[, freewill], as.numeric))

# Calculating the determinism

df$de = rowSums(sapply(df[, determinism], as.numeric))

# Calculating the dualism 

df$du = rowSums(sapply(df[, dualism], as.numeric))

############################################################################################

# Calculating the internal & external traits

internal = c(9, 11, 13, 15, 17, 19, 21, 23)
external = c(10, 12, 14, 16, 18, 20, 22, 24)

df$int = rowSums(sapply(df[, internal], as.numeric))
df$ext = rowSums(sapply(df[, external], as.numeric))

# Calculating the correspondence bias score

df$corre_bias = df$int - df$ext

# Writing the data-frame into file

write.table(df, file = "survey_anti.csv", sep = ",", col.names = TRUE,
            row.names = FALSE, qmethod = "double")


