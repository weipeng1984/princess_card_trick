
# manipulation check
library(car)
library(knitr)
library(apa)
library(ggplot2)

# perform t test in this study

df_pro = read.csv(file.choose(), header = TRUE, sep = ',', stringsAsFactors = FALSE)

df_anti = read.csv(file.choose(), header = TRUE, sep = ',', stringsAsFactors = FALSE)


freewill = stack(list(anti = df_anti$fw, pro = df_pro$fw))
determinism = stack(list(anti = df_anti$de, pro = df_pro$de))
dualism = stack(list(anti = df_anti$du, pro = df_pro$du))

# for free will sub-scale

t_apa(t_test(df_anti$fw, df_pro$fw, var.equal = FALSE))


# for determinism subscale

t_apa(t_test(df_anti$de, df_pro$de, var.equal = TRUE))


# for dualism subscale

t_apa(t_test(df_anti$du, df_pro$du, var.equal = FALSE))


# descriptive data - free will

library(dplyr)
# Summarize data by groups
fw = freewill %>% # "Start with the data set we imported, d 
  group_by(ind) %>% # Then group d by IV
  summarize(N = length(values), # Then summarize each group
            Mean = mean(values),
            SD = sd(values),
            SE = SD/sqrt(N)) 
kable(fw, digits = 2)

# descriptive data - determinism

# Summarize data by groups
de = determinism %>% # "Start with the data set we imported, d 
  group_by(ind) %>% # Then group d by IV
  summarize(N = length(values), # Then summarize each group
            Mean = mean(values),
            SD = sd(values),
            SE = SD/sqrt(N)) 
kable(de, digits = 2)

# descriptive data - dualism

# Summarize data by groups
du = dualism %>% # "Start with the data set we imported, d 
  group_by(ind) %>% # Then group d by IV
  summarize(N = length(values), # Then summarize each group
            Mean = mean(values),
            SD = sd(values),
            SE = SD/sqrt(N)) 
kable(du, digits = 2)

#################################################################
# now we plotting

# for free will 

fw = ggplot(freewill, aes(x = ind, y = values, fill = ind)) + 
  geom_violin(trim = FALSE) + 
  geom_boxplot(width = 0.1, fill = "white") 
fw + xlab("Group") + ylab("Belief in free will") + 
  theme(axis.title.y = element_text(color = 'black', family = 'Arial', face = 'bold', size = 18, vjust = 0.5, angle = 90), 
                                                         axis.title.x = element_text(color = 'black', family = 'Arial',
                                                                                     face = 'bold', size = 18, hjust = 0.5, angle = 0), 
                                                         legend.text = element_text(size = 14), legend.title = element_text(size = 14)) + 
  labs(fill = "Group")



